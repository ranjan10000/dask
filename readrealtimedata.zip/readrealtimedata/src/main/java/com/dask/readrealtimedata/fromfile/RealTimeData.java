package com.dask.readrealtimedata.fromfile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class RealTimeData {
	private static final Logger logger = Logger.getLogger(RealTimeData.class);
	private final ObjectMapper mapper = new ObjectMapper();
	FileReader fileReader;
	Object reader;
	String keyName = "";
	String keyValue = "";

	private Map<String, String> dimension;
	private Map<String, Object> realtimeData;
	private Boolean pumpup;
	private Boolean pumpupComplete;
	private Boolean heartbeat;
	private String extra;
	private String sourceId;
	private String producerId;
	private String eventAction;
	private String pumpupIdentifier;

	public String getPumpupIdentifier() {
		return pumpupIdentifier;
	}

	public void setPumpupIdentifier(String pumpupIdentifier) {
		this.pumpupIdentifier = pumpupIdentifier;
	}

	public String getExtra() {
		return extra;
	}

	public void setExtra(String extra) {
		this.extra = extra;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getProducerId() {
		return producerId;
	}

	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}

	public String getEventAction() {
		return eventAction;
	}

	public void setEventAction(String eventAction) {
		this.eventAction = eventAction;
	}

	public Map<String, String> getDimension() {
		return dimension;
	}

	public void setDimension(Map<String, String> dimension) {
		this.dimension = dimension;
	}

	public Map<String, Object> getRealtimeData() {
		return realtimeData;
	}

	public void setRealtimeData(Map<String, Object> realtimeData) {
		this.realtimeData = realtimeData;
	}

	public Boolean getPumpup() {
		return pumpup;
	}

	public void setPumpup(Boolean pumpup) {
		this.pumpup = pumpup;
	}

	public Boolean getPumpupComplete() {
		return pumpupComplete;
	}

	public void setPumpupComplete(Boolean pumpupComplete) {
		this.pumpupComplete = pumpupComplete;
	}

	public Boolean getHeartbeat() {
		return heartbeat;
	}

	public void setHeartbeat(Boolean heartbeat) {
		this.heartbeat = heartbeat;
	}

	@Override
	public String toString() {
		return "RealTimeData [dimension=" + dimension + ", realtimeData=" + realtimeData + ", pumpup=" + pumpup
				+ ", pumpupComplete=" + pumpupComplete + ", heartbeat=" + heartbeat + "]";
	}

	public void readFileData(RealTimeData realData) {

		File file = new File("D:\\json\\jsonvalue.txt");

		try {
			fileReader = new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader bufferedReader = new BufferedReader(fileReader);

		try {
			reader = new JSONParser().parse(bufferedReader);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}

		// System.out.println(reader);
		logger.info(reader);
		realData = mapper.convertValue(reader, RealTimeData.class);
		for (int i = 0; i < realData.getDimension().size(); i++) {
			keyName = (String) realData.getDimension().keySet().toArray()[i];
			keyValue = realData.getDimension().get(keyName);
			logger.info(keyName + " : " + keyValue);
			System.out.println(keyName + " : " + keyValue);
		}
		System.out.println("-------------------------------------------------------------------------");
		for (int i = 0; i < realData.getRealtimeData().size(); i++) {
			keyName = (String) realData.getRealtimeData().keySet().toArray()[i];
			keyValue = realData.getDimension().get(keyName);
			logger.info(keyName + " : " + keyValue);
			System.out.println(keyName + " : " + keyValue);
		}


		// if(realData.getDimension().keySet().toArray())
	}

	static RealTimeData data = new RealTimeData();

	public static void main(String[] args) {

		data.readFileData(null);

	}
}
