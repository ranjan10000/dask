package com.dask.readrealtimedata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadrealtimedataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadrealtimedataApplication.class, args);
	}

}
